"""Fold-local preprocessing and complementary regularized regression models."""

import numpy as np
from scipy.special import boxcox1p
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.impute import SimpleImputer
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import ElasticNet, Lasso, Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, RobustScaler
from sklearn.svm import SVR

from features import AmesFeatures


class SkewedNumeric(TransformerMixin, BaseEstimator):
    """Choose skewed nonnegative columns using training-fold data only."""
    def __init__(self, threshold=.75, power=.15):
        self.threshold = threshold
        self.power = power

    def fit(self, X, y=None):
        X = np.asarray(X, dtype=float)
        from scipy.stats import skew
        self.columns_ = (skew(X, axis=0, nan_policy="omit") > self.threshold) & (np.nanmin(X, axis=0) >= 0)
        return self

    def transform(self, X):
        X = np.asarray(X, dtype=float).copy()
        X[:, self.columns_] = boxcox1p(np.maximum(X[:, self.columns_], 0), self.power)
        return X


def make_preprocessor():
    return Pipeline([
        ("features", AmesFeatures()),
        ("columns", ColumnTransformer([
            ("numeric", Pipeline([
                ("impute", SimpleImputer(strategy="median")),
                ("skew", SkewedNumeric()),
                ("scale", RobustScaler()),
            ]), make_column_selector(dtype_include=np.number)),
            ("categorical", OneHotEncoder(handle_unknown="ignore", sparse_output=False),
             make_column_selector(dtype_include=["object", "string"])),
        ], sparse_threshold=0)),
    ])


def make_linear_models():
    """Return independent pipelines accepting raw CSV feature DataFrames."""
    estimators = {
        "lasso": Lasso(alpha=.00045, max_iter=40000, tol=1e-5),
        "elasticnet": ElasticNet(alpha=.0005, l1_ratio=.9, max_iter=40000, tol=1e-5),
        "ridge": Ridge(alpha=12),
        "kernelridge": KernelRidge(alpha=.6, kernel="polynomial", degree=2, coef0=2.5),
        "svr": SVR(C=20, epsilon=.008, gamma=.0003),
    }
    return {name: Pipeline([("preprocess", make_preprocessor()), ("model", estimator)])
            for name, estimator in estimators.items()}
