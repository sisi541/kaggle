"""Fold-safe nonlinear features for full-data Ames linear regressions."""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from features import build_features


AREA_COLUMNS = ['GrLivArea', '1stFlrSF', '2ndFlrSF', 'TotalBsmtSF', 'BsmtFinSF1',
                'BsmtFinSF2', 'BsmtUnfSF', 'GarageArea', 'LotArea', 'MasVnrArea']


class FullAmesFeatures(TransformerMixin, BaseEstimator):
    def __init__(self, interactions=True, tame_interactions=False, neighborhood_quantile=None, subgroup_cap=False):
        self.interactions = interactions
        self.tame_interactions = tame_interactions
        self.neighborhood_quantile = neighborhood_quantile
        self.subgroup_cap = subgroup_cap

    def fit(self, X, y=None):
        if self.neighborhood_quantile is not None:
            # All locations follow the same rule. No target is consulted.
            self.global_caps_ = X[AREA_COLUMNS].quantile(self.neighborhood_quantile)
            self.location_caps_ = X.groupby('Neighborhood')[AREA_COLUMNS].quantile(self.neighborhood_quantile)
            counts = X.groupby('Neighborhood').size()
            self.location_caps_ = self.location_caps_.loc[counts >= 15]
            if self.subgroup_cap:
                groups = X.groupby(['Neighborhood', 'SaleCondition'])
                self.subgroup_caps_ = groups[AREA_COLUMNS].quantile(self.neighborhood_quantile)
                self.subgroup_caps_ = self.subgroup_caps_.loc[groups.size() >= 2]
        return self

    def transform(self, X):
        raw = X.copy()
        if self.neighborhood_quantile is not None:
            # Recompute all composite areas after clipping component areas.
            # This changes no rows, labels, or sample weights.
            for col in AREA_COLUMNS:
                cap = raw.Neighborhood.map(self.location_caps_[col]).fillna(self.global_caps_[col])
                if self.subgroup_cap:
                    keys = pd.MultiIndex.from_frame(raw[['Neighborhood','SaleCondition']])
                    subgroup = self.subgroup_caps_[col].reindex(keys).to_numpy()
                    cap = pd.Series(subgroup, index=raw.index).fillna(cap)
                raw[col] = raw[col].where(raw[col] <= cap, cap).where(raw[col].notna())
        x = build_features(raw)
        # Sale attributes and location distinguish pricing regimes; no prices
        # enter these row-local interactions, and no house ID is used.
        if self.interactions:
            interactions = {}
            for a, b in [('Neighborhood', 'SaleCondition'), ('Neighborhood', 'SaleType'),
                         ('Neighborhood', 'MSSubClass'), ('BldgType', 'HouseStyle'),
                         ('OverallQual', 'SaleCondition')]:
                interactions[a+'__'+b] = x[a].astype(str) + '__' + x[b].astype(str)
            x = pd.concat([x, pd.DataFrame(interactions, index=x.index)], axis=1)
        # For the nonlinear design, the large polynomial quality/area terms
        # are redundant with bounded splines and can induce extrapolation.
        if self.tame_interactions:
            x = x.drop(columns=[c for c in x if c.endswith('_Quality') or c in ['OverallQualCubed']])
        return x


class QuantileClipper(TransformerMixin, BaseEstimator):
    """Learn caps for numerical feature tails from training rows only."""
    def __init__(self, quantile=.995):
        self.quantile = quantile

    def fit(self, X, y=None):
        X = np.asarray(X, dtype=float)
        self.upper_ = np.quantile(X, self.quantile, axis=0)
        self.lower_ = np.quantile(X, 1-self.quantile, axis=0)
        return self

    def transform(self, X):
        return np.clip(np.asarray(X, dtype=float), self.lower_, self.upper_)
