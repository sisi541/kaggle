"""Native categorical CatBoost regressors for Ames House Prices.

All predictors are computed independently per row, never from SalePrice.
Use log1p(SalePrice) as the regression target. Missing numeric values are
handled natively by CatBoost and missing categories use a stable sentinel.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from sklearn.model_selection import KFold


CAT_CONFIGS = {
    'cat_d4': dict(iterations=4000, depth=4, learning_rate=0.03,
                   l2_leaf_reg=5, random_strength=0.5, bagging_temperature=0.4),
    'cat_d5': dict(iterations=3500, depth=5, learning_rate=0.03,
                   l2_leaf_reg=5, random_strength=0.5, bagging_temperature=0.4),
}


def cat_features(frame: pd.DataFrame) -> pd.DataFrame:
    x = frame.drop(columns=['Id', 'SalePrice'], errors='ignore').copy()
    # Integer identifiers with nonmetric meanings should remain categorical.
    for col in ['MSSubClass', 'MoSold']:
        x[col] = x[col].fillna(-1).astype(int).astype(str)
    zero = lambda col: pd.to_numeric(x[col], errors='coerce').fillna(0)
    x['TotalSF'] = zero('TotalBsmtSF') + zero('1stFlrSF') + zero('2ndFlrSF')
    x['TotalLivingSF'] = zero('GrLivArea') + zero('TotalBsmtSF')
    x['TotalBath'] = zero('FullBath') + 0.5 * zero('HalfBath') + zero('BsmtFullBath') + 0.5 * zero('BsmtHalfBath')
    x['TotalPorchSF'] = sum(zero(c) for c in ['WoodDeckSF', 'OpenPorchSF', 'EnclosedPorch', '3SsnPorch', 'ScreenPorch'])
    x['AgeAtSale'] = zero('YrSold') - zero('YearBuilt')
    x['YearsSinceRemodel'] = zero('YrSold') - zero('YearRemodAdd')
    x['Remodeled'] = (zero('YearBuilt') != zero('YearRemodAdd')).astype(int)
    for col in ['PoolArea', 'TotalBsmtSF', 'GarageArea', 'Fireplaces', '2ndFlrSF']:
        x['Has' + col] = (zero(col) > 0).astype(int)
    for col in x.select_dtypes(include=['object', 'string']).columns:
        x[col] = x[col].fillna('__MISSING__').astype(str)
    return x


def make_cat_model(name: str = 'cat_d4', seed: int = 42, threads: int = 1):
    return CatBoostRegressor(**CAT_CONFIGS[name], loss_function='RMSE',
                             random_seed=seed, thread_count=threads,
                             verbose=False, allow_writing_files=False)


def run_cv(data_dir='data', output_dir='experiment_cat', models=None):
    data_dir, output_dir = Path(data_dir), Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    train = pd.read_csv(data_dir / 'train.csv')
    train = train.loc[~((train.GrLivArea > 4000) & (train.SalePrice < 300000))].reset_index(drop=True)
    test = pd.read_csv(data_dir / 'test.csv')
    y = np.log1p(train.SalePrice.to_numpy())
    x, xt = cat_features(train), cat_features(test)
    cats = list(x.select_dtypes(include=['object', 'string']).columns)
    kfold = KFold(n_splits=5, shuffle=True, random_state=42)
    summary = {}
    for name in (models or ['cat_d4']):
        oof, testpred = np.empty(len(y)), np.zeros(len(test))
        scores = []
        for fold, (it, iv) in enumerate(kfold.split(x), 1):
            model = make_cat_model(name)
            model.fit(x.iloc[it], y[it], cat_features=cats)
            oof[iv] = model.predict(x.iloc[iv])
            testpred += model.predict(xt) / kfold.n_splits
            score = float(np.sqrt(np.mean((y[iv] - oof[iv]) ** 2)))
            scores.append(score)
            print(name, 'fold', fold, 'rmse', round(score, 6), flush=True)
        score = float(np.sqrt(np.mean((y - oof) ** 2)))
        summary[name] = dict(rmse=score, folds=scores, params=CAT_CONFIGS[name])
        np.savez_compressed(output_dir / f'{name}.npz', oof=oof, test=testpred,
                            train_ids=train.Id.to_numpy(), test_ids=test.Id.to_numpy())
        print(name, 'OOF', score, flush=True)
        (output_dir / 'metrics.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', default='data')
    parser.add_argument('--output-dir', default='experiment_cat')
    parser.add_argument('--models', nargs='+', default=None)
    args = parser.parse_args()
    run_cv(args.data_dir, args.output_dir, args.models)
