"""All-record cross-validation: no row filtering, label trimming or downweighting."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import KFold
from threadpoolctl import threadpool_limits


def read_full(data_dir='data'):
    root = Path(data_dir)
    train = pd.read_csv(root/'train.csv')
    test = pd.read_csv(root/'test.csv')
    assert len(train) == 1460 and train.Id.is_unique and test.Id.is_unique
    assert set(train.columns) == set(test.columns) | {'SalePrice'}
    return train.drop(columns='SalePrice'), np.log1p(train.SalePrice.to_numpy()), test


def log_rmse(y_log1p, p_log1p):
    y, p = np.expm1(y_log1p), np.expm1(p_log1p)
    if not np.isfinite(p).all() or (p <= 0).any():
        raise ValueError('Invalid predicted price')
    return float(np.sqrt(np.mean((np.log(y)-np.log(p))**2)))


def evaluate_full(models, output_dir, seed=42, data_dir='data'):
    x,y,test = read_full(data_dir)
    output = Path(output_dir); output.mkdir(parents=True,exist_ok=True)
    metrics_file=output/f'metrics_seed{seed}.json'
    metrics=json.loads(metrics_file.read_text()) if metrics_file.exists() else {}
    cv=KFold(n_splits=5,shuffle=True,random_state=seed)
    with threadpool_limits(limits=1):
        for name,template in models.items():
            oof=np.empty(len(x)); ptest=np.zeros(len(test)); scores=[]
            fold_membership=np.empty(len(x),dtype=int)
            for f,(it,iv) in enumerate(cv.split(x),1):
                model=clone(template)
                model.fit(x.iloc[it],y[it])
                oof[iv]=model.predict(x.iloc[iv]); ptest+=model.predict(test)/5
                fold_membership[iv]=f
                scores.append(log_rmse(y[iv],oof[iv]))
                print(f'{name} seed={seed} fold={f} logRMSE={scores[-1]:.6f}',flush=True)
            score=log_rmse(y,oof)
            metrics[name]={'exact_log_rmse':score,'folds':scores,'n_train':len(x),
                'seed':seed,'n_splits':5,'excluded_ids':[],
                'special_sales':{str(hid):{'actual':float(np.expm1(y[x.Id.to_numpy()==hid][0])),
                      'oof_prediction':float(np.expm1(oof[x.Id.to_numpy()==hid][0]))}
                      for hid in [524,1299]}}
            np.savez_compressed(output/f'{name}_seed{seed}.npz',oof=oof,test=ptest,
                  train_ids=x.Id.to_numpy(),test_ids=test.Id.to_numpy(),folds=fold_membership)
            metrics_file.write_text(json.dumps(metrics,indent=2)+'\n')
            print(f'{name} seed={seed} FULL1460 logRMSE={score:.6f}',flush=True)
    return metrics
