"""Reproduce submission2926.csv using fold-local Ames feature pipelines.

Run: python train.py --data-dir data --output-dir results
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.base import clone
from sklearn.model_selection import KFold
from threadpoolctl import threadpool_limits

from linear_models import make_linear_models

# Fixed before the second-seed confirmation, without test-set labels.
WEIGHTS = {'lasso': 0.5, 'svr': 0.5}


def exact_log_rmse(prices, predicted_log1p):
    predicted_prices = np.expm1(np.asarray(predicted_log1p))
    if not np.isfinite(predicted_prices).all() or (predicted_prices <= 0).any():
        raise ValueError('Predicted prices must be finite and strictly positive.')
    return float(np.sqrt(np.mean((np.log(prices) - np.log(predicted_prices)) ** 2)))


def read_data(data_dir):
    train = pd.read_csv(data_dir / 'train.csv')
    test = pd.read_csv(data_dir / 'test.csv')
    sample = pd.read_csv(data_dir / 'sample_submission.csv')
    if set(train.columns) != set(test.columns) | {'SalePrice'}:
        raise ValueError('Training/test schemas do not match.')
    if not train.Id.is_unique or not test.Id.is_unique:
        raise ValueError('House IDs must be unique.')
    if not sample.Id.equals(test.Id):
        raise ValueError('Test ID order does not match sample submission.')
    if train.SalePrice.isna().any() or (train.SalePrice <= 0).any():
        raise ValueError('Invalid training prices.')
    excluded = (train.GrLivArea > 4000) & (train.SalePrice < 300000)
    excluded_ids = train.loc[excluded, 'Id'].astype(int).tolist()
    train = train.loc[~excluded].reset_index(drop=True)
    return train, test, excluded_ids


def cross_validate(x, y, prices, models, seed, output):
    folds = KFold(n_splits=5, shuffle=True, random_state=seed)
    oof = {name: np.empty(len(x)) for name in WEIGHTS}
    fold_scores = {name: [] for name in [*WEIGHTS, 'blend']}
    for fold, (it, iv) in enumerate(folds.split(x), 1):
        for name in WEIGHTS:
            fitted = clone(models[name]).fit(x.iloc[it], y[it])
            oof[name][iv] = fitted.predict(x.iloc[iv])
            fold_scores[name].append(exact_log_rmse(prices[iv], oof[name][iv]))
        blend = sum(WEIGHTS[n] * oof[n][iv] for n in WEIGHTS)
        score = exact_log_rmse(prices[iv], blend)
        fold_scores['blend'].append(score)
        print(f'seed={seed}, fold={fold}, blend log RMSE={score:.6f}', flush=True)
    blend = sum(WEIGHTS[n] * oof[n] for n in WEIGHTS)
    scores = {name: exact_log_rmse(prices, pred) for name, pred in oof.items()}
    scores['blend'] = exact_log_rmse(prices, blend)
    oof_frame = pd.DataFrame({'Id': x.Id, 'SalePrice': prices,
                              **{n + '_log1p': p for n, p in oof.items()},
                              'blend_log1p': blend})
    oof_frame.to_csv(output / f'oof_seed{seed}.csv', index=False)
    print(f'seed={seed}, overall log RMSE={scores["blend"]:.6f}', flush=True)
    return {'seed': seed, 'n_splits': 5, 'exact_log_rmse': scores,
            'fold_exact_log_rmse': fold_scores}


def run(data_dir, output, seeds=(42, 2026), save_models=False):
    output.mkdir(parents=True, exist_ok=True)
    train, test, excluded_ids = read_data(data_dir)
    x = train.drop(columns=['SalePrice'])
    prices = train.SalePrice.to_numpy()
    y = np.log1p(prices)
    models = make_linear_models()
    report = {
        'metric': 'RMSE(log(actual SalePrice), log(predicted SalePrice))',
        'training_target': 'log1p(SalePrice)',
        'original_training_rows': len(train) + len(excluded_ids),
        'cleaned_training_rows': len(train), 'excluded_training_ids': excluded_ids,
        'outlier_rule': 'GrLivArea > 4000 and SalePrice < 300000',
        'test_rows': len(test), 'weights_in_log1p_space': WEIGHTS,
        'final_strategy': 'Refit both pipelines on all 1458 cleaned training rows.',
        'limitations': [
            'CV excludes the two exceptional training sales; it is not a full-data CV score.',
            'Seed 42 was used for model selection; seed 2026 confirms the frozen linear blend.',
            'No test labels or external sale-price data were used.',
            'No Kaggle submission was made; the online score is unknown.',
        ],
        'versions': {'python': platform.python_version(), 'numpy': np.__version__,
                     'pandas': pd.__version__, 'scipy': scipy.__version__,
                     'scikit-learn': sklearn.__version__},
        'data_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in [data_dir / 'train.csv', data_dir / 'test.csv']},
        'validation': [],
    }
    with threadpool_limits(limits=1):
        for seed in seeds:
            report['validation'].append(cross_validate(x, y, prices, models, seed, output))
        final_log = np.zeros(len(test))
        components = pd.DataFrame({'Id': test.Id})
        for name, weight in WEIGHTS.items():
            fitted = clone(models[name]).fit(x, y)
            pred = fitted.predict(test)
            final_log += weight * pred
            components[name + '_SalePrice'] = np.expm1(pred)
            if save_models:
                import joblib
                joblib.dump(fitted, output / f'{name}.joblib')
            print(f'Full-data refit complete: {name}', flush=True)
    submission = pd.DataFrame({'Id': test.Id.astype(int), 'SalePrice': np.expm1(final_log)})
    if list(submission.columns) != ['Id', 'SalePrice'] or len(submission) != len(test):
        raise ValueError('Invalid submission shape.')
    if not submission.Id.equals(test.Id):
        raise ValueError('Submission IDs are out of order.')
    if not np.isfinite(submission.SalePrice).all() or not (submission.SalePrice > 0).all():
        raise ValueError('Invalid submission prices.')
    path = output / 'submission2926.csv'
    submission.to_csv(path, index=False, float_format='%.6f')
    # Check the actual CSV after serialization, not just the in-memory frame.
    checked = pd.read_csv(path)
    if checked.shape != (len(test), 2) or not checked.Id.equals(test.Id):
        raise ValueError('Serialized submission is invalid.')
    components.to_csv(output / 'prediction_components.csv', index=False)
    report['submission_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    report['prediction_range'] = {'min': float(checked.SalePrice.min()),
                                  'max': float(checked.SalePrice.max())}
    (output / 'validation_report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(f'Wrote {path}: {len(checked)} rows; validated Id order and positive finite prices.', flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=Path('data'))
    parser.add_argument('--output-dir', type=Path, default=Path('results'))
    parser.add_argument('--skip-cv', action='store_true', help='Refit only; do not claim a new CV result.')
    parser.add_argument('--save-models', action='store_true')
    args = parser.parse_args()
    run(args.data_dir, args.output_dir, seeds=() if args.skip_cv else (42, 2026),
        save_models=args.save_models)
