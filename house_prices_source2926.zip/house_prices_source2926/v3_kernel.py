"""Additional kernel regressions, retaining every original Ames record."""
import argparse
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, RobustScaler, StandardScaler, MinMaxScaler
from sklearn.svm import SVR
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import Ridge, ElasticNet
from features import build_features
from full_linear_features import FullAmesFeatures
from linear_models import SkewedNumeric
from full_cv import evaluate_full

AREA_COLS=['GrLivArea','TotalBsmtSF','1stFlrSF','2ndFlrSF','LotArea','GarageArea','BsmtFinSF1','BsmtFinSF2','BsmtUnfSF']

class KernelFeatures(BaseEstimator, TransformerMixin):
    def __init__(self, area_quantile=None, neighborhood=None, tame=True):
        self.area_quantile=area_quantile;self.neighborhood=neighborhood;self.tame=tame
    def fit(self,X,y=None):
        self.caps_=X[AREA_COLS].quantile(self.area_quantile) if self.area_quantile else None
        self.features_=FullAmesFeatures(interactions=True, neighborhood_quantile=self.neighborhood)
        raw=X.copy()
        if self.caps_ is not None:raw[AREA_COLS]=raw[AREA_COLS].clip(upper=self.caps_,axis=1)
        self.features_.fit(raw)
        return self
    def transform(self,X):
        raw=X.copy()
        if self.caps_ is not None:raw[AREA_COLS]=raw[AREA_COLS].clip(upper=self.caps_,axis=1)
        x=self.features_.transform(raw)
        if self.tame:x=x.drop(columns=[c for c in x if c.endswith('_Quality') or c in ['OverallQualSquared','OverallQualCubed']])
        return x

class ArrayCap(BaseEstimator,TransformerMixin):
    def __init__(self,quantile=None):self.quantile=quantile
    def fit(self,X,y=None):
        self.lo_=np.quantile(X,1-self.quantile,axis=0) if self.quantile else None
        self.hi_=np.quantile(X,self.quantile,axis=0) if self.quantile else None
        return self
    def transform(self,X):return np.clip(X,self.lo_,self.hi_) if self.quantile else X


def preprocess(scale='robust',cap=None,area=None,neighborhood=None,tame=True,geo_weight=0):
    scaler={'robust':RobustScaler(),'standard':StandardScaler(),'minmax':MinMaxScaler()}[scale]
    cols=[('numeric',Pipeline([('impute',SimpleImputer(strategy='median')),('cap',ArrayCap(cap)),('skew',SkewedNumeric()),('scale',scaler)]),make_column_selector(dtype_include=np.number)),
          ('category',OneHotEncoder(handle_unknown='ignore',sparse_output=False),make_column_selector(dtype_include=['object','string']))]
    if geo_weight:
        cols.append(('geography',OneHotEncoder(handle_unknown='ignore',sparse_output=False),['Neighborhood','Neighborhood__SaleCondition','Neighborhood__SaleType']))
    return Pipeline([('features',KernelFeatures(area_quantile=area,neighborhood=neighborhood,tame=tame)),
      ('columns',ColumnTransformer(cols,sparse_threshold=0,transformer_weights={'geography':geo_weight} if geo_weight else None))])


def make_v3_kernel_models():
    configs={
      'svr_area99':(SVR(C=20,epsilon=.008,gamma=.0003),dict(area=.99,tame=False)),
      'svr_tame99':(SVR(C=20,epsilon=.008,gamma=.0003),dict(area=.99)),
      'svr_local':(SVR(C=10,epsilon=.008,gamma=.001),dict(area=.99)),
      'svr_standard':(SVR(C=20,epsilon=.008,gamma=.001),dict(scale='standard',area=.99)),
      'svr_standard_soft':(SVR(C=10,epsilon=.01,gamma=.0003),dict(scale='standard',area=.995)),
      'svr_neigh98':(SVR(C=20,epsilon=.008,gamma=.0003),dict(neighborhood=.98,cap=.99)),
      'svr_neigh98_soft':(SVR(C=10,epsilon=.008,gamma=.00015),dict(neighborhood=.98,cap=.99)),
      'svr_neigh98_c10':(SVR(C=10,epsilon=.008,gamma=.0003),dict(neighborhood=.98,cap=.99)),
      'svr_neigh97':(SVR(C=20,epsilon=.008,gamma=.0003),dict(neighborhood=.97,cap=.99)),
      'svr_geo8':(SVR(C=20,epsilon=.008,gamma=.0003),dict(neighborhood=.98,cap=.99,geo_weight=8)),
      'svr_geo16':(SVR(C=20,epsilon=.008,gamma=.0003),dict(neighborhood=.98,cap=.99,geo_weight=16)),
      'krr_poly':(KernelRidge(alpha=.6,kernel='polynomial',degree=2,coef0=2.5),dict(area=.99)),
      'krr_rbf':(KernelRidge(alpha=.01,kernel='rbf',gamma=.0003),dict(area=.99)),
      'krr_rbf_local':(KernelRidge(alpha=.03,kernel='rbf',gamma=.001),dict(area=.99)),
      'enet_area99':(ElasticNet(alpha=.0005,l1_ratio=.9,max_iter=50000,tol=1e-5),dict(area=.99)),
    }
    return {n:Pipeline([('preprocess',preprocess(**kw)),('model',m)])for n,(m,kw)in configs.items()}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=42);p.add_argument('--models',nargs='+');a=p.parse_args()
    models=make_v3_kernel_models()
    if a.models:models={n:models[n]for n in a.models}
    evaluate_full(models,'v3_experiments/kernel',seed=a.seed)
