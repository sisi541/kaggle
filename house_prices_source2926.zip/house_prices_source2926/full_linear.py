"""Ridge/Lasso candidates that retain every Ames training record."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Lasso, Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, RobustScaler, SplineTransformer
from sklearn.svm import SVR
from sklearn.model_selection import KFold
from threadpoolctl import threadpool_limits
from full_linear_features import FullAmesFeatures, QuantileClipper
from linear_models import SkewedNumeric


SPLINE_COLUMNS=['GrLivArea','TotalBsmtSF','1stFlrSF','GarageArea','LotArea',
                'OverallQual','YearBuilt','YearRemodAdd','TotalSF','TotalBath']


def make_preprocessor(interactions=True, clip=None, spline=False, neighborhood_quantile=None, subgroup_cap=False):
    num=[('impute',SimpleImputer(strategy='median'))]
    if clip:
        num.append(('clip',QuantileClipper(clip)))
    num += [('skew',SkewedNumeric()),('scale',RobustScaler())]
    cols=[('numeric',Pipeline(num),make_column_selector(dtype_include=np.number)),
          ('categorical',OneHotEncoder(handle_unknown='ignore',sparse_output=False),
           make_column_selector(dtype_include=['object','string']))]
    if spline:
        cols.append(('spline',Pipeline([
            ('impute',SimpleImputer(strategy='median')),
            ('spline',SplineTransformer(n_knots=6,degree=2,knots='quantile',extrapolation='constant',include_bias=False)),
            ('scale',RobustScaler()),
        ]),SPLINE_COLUMNS))
    return Pipeline([('features',FullAmesFeatures(interactions=interactions,tame_interactions=spline,neighborhood_quantile=neighborhood_quantile,subgroup_cap=subgroup_cap)),
                     ('columns',ColumnTransformer(cols,sparse_threshold=0))])


def make_full_linear_models():
    configs={
        'full_lasso_interactions':(Lasso(alpha=.0005,max_iter=50000,tol=1e-5),True,None,False),
        'full_ridge_interactions':(Ridge(alpha=30),True,None,False),
        'full_lasso_spline':(Lasso(alpha=.0005,max_iter=50000,tol=1e-5),True,.995,True),
        'full_ridge_spline':(Ridge(alpha=30),True,.995,True),
        'full_lasso_clip':(Lasso(alpha=.0005,max_iter=50000,tol=1e-5),True,.99,False),
        'full_ridge_clip':(Ridge(alpha=60),True,.99,False),
    }
    result = {name:Pipeline([('preprocess',make_preprocessor(ints,clip,spline)),('model',model)])
              for name,(model,ints,clip,spline) in configs.items()}
    for quantile in [.99, .98]:
        name = 'full_lasso_neighborhood' + str(int(quantile*100))
        result[name] = Pipeline([('preprocess',make_preprocessor(True,.99,False,quantile)),
                                 ('model',Lasso(alpha=.0005,max_iter=50000,tol=1e-5))])
    result['full_svr_clip'] = Pipeline([('preprocess',make_preprocessor(True,.99,False)),
                                        ('model',SVR(C=20,epsilon=.008,gamma=.0003))])
    result['full_lasso_subgroup98'] = Pipeline([('preprocess',make_preprocessor(True,.99,False,.98,True)),
                                                 ('model',Lasso(alpha=.0005,max_iter=50000,tol=1e-5))])
    result['full_svr_subgroup98'] = Pipeline([('preprocess',make_preprocessor(True,.99,False,.98,True)),
                                               ('model',SVR(C=20,epsilon=.008,gamma=.0003))])
    return result


def run_cv(seed=42, names=None, data_dir='data', output_dir='full_experiments/linear'):
    train=pd.read_csv(Path(data_dir)/'train.csv');test=pd.read_csv(Path(data_dir)/'test.csv')
    assert len(train)==1460
    x=train.drop(columns='SalePrice');y=np.log1p(train.SalePrice.to_numpy())
    output=Path(output_dir);output.mkdir(parents=True,exist_ok=True)
    metrics_path=output/f'metrics_seed{seed}.json'
    metrics=json.loads(metrics_path.read_text()) if metrics_path.exists() else {}
    models=make_full_linear_models()
    if names:models={name:models[name] for name in names}
    with threadpool_limits(limits=1):
        for name,template in models.items():
            oof=np.empty(len(train));pred=np.zeros(len(test));foldscores=[]
            for fold,(it,iv) in enumerate(KFold(5,shuffle=True,random_state=seed).split(x),1):
                m=clone(template).fit(x.iloc[it],y[it]);oof[iv]=m.predict(x.iloc[iv]);pred+=m.predict(test)/5
                score=float(np.sqrt(np.mean((np.log(train.SalePrice.to_numpy()[iv])-np.log(np.expm1(oof[iv])))**2)))
                foldscores.append(score)
                print(name,'seed',seed,'fold',fold,round(score,6),flush=True)
            score=float(np.sqrt(np.mean((np.log(train.SalePrice)-np.log(np.expm1(oof)))**2)))
            metrics[name]={'exact_log_rmse':score,'folds':foldscores,
                           'outlier_oof_prices':dict(zip(train.loc[train.Id.isin([524,1299]),'Id'].astype(str),np.expm1(oof[train.Id.isin([524,1299])]).tolist()))}
            np.savez_compressed(output/f'{name}_seed{seed}.npz',oof=oof,test=pred,train_ids=train.Id.to_numpy(),test_ids=test.Id.to_numpy())
            metrics_path.write_text(json.dumps(metrics,indent=2)+'\n')
            print(name,'seed',seed,'OOF',score,flush=True)
    return metrics


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=42);p.add_argument('--models',nargs='+');args=p.parse_args()
    run_cv(args.seed,args.models)
