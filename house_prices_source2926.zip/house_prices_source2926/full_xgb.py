"""CPU XGBoost and generic cross features, with every original training row."""
import argparse
import numpy as np
from sklearn.base import BaseEstimator,TransformerMixin
from sklearn.compose import ColumnTransformer,make_column_selector
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from xgboost import XGBRegressor
from features import build_features
from full_cv import evaluate_full


class CrossFeatures(BaseEstimator,TransformerMixin):
    def fit(self,X,y=None):return self
    def transform(self,X):
        x=build_features(X).copy()
        for a,b in [('Neighborhood','SaleCondition'),('Neighborhood','SaleType'),
                    ('Neighborhood','OverallQual'),('HouseStyle','MSSubClass')]:
            x[a+'__'+b]=x[a].astype(str)+'__'+x[b].astype(str)
        for c in ['GrLivArea','TotalBsmtSF','LotArea','TotalSF','GarageArea']:
            x['log_'+c]=np.log1p(x[c].clip(lower=0))
        return x


def make_full_xgb_models(threads=1):
    common=dict(objective='reg:squarederror',tree_method='hist',n_jobs=threads,
                random_state=42,subsample=.8,colsample_bytree=.75,
                learning_rate=.025,reg_alpha=.02,reg_lambda=4)
    ests={
        'xgb_d3':XGBRegressor(**common,n_estimators=1800,max_depth=3,min_child_weight=3),
        'xgb_d2':XGBRegressor(**common,n_estimators=2200,max_depth=2,min_child_weight=3),
        'xgb_d4':XGBRegressor(**common,n_estimators=1400,max_depth=4,min_child_weight=5),
    }
    result={}
    for name,est in ests.items():
        result[name]=Pipeline([
            ('features',CrossFeatures()),
            ('columns',ColumnTransformer([
                ('numeric',SimpleImputer(strategy='median'),make_column_selector(dtype_include=np.number)),
                ('category',OneHotEncoder(handle_unknown='ignore',sparse_output=False),
                 make_column_selector(dtype_include=['object','string'])),
            ],sparse_threshold=0)),
            ('model',est)])
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=42)
    p.add_argument('--models',nargs='+');p.add_argument('--output-dir',default='full_experiments/xgb')
    args=p.parse_args();models=make_full_xgb_models()
    if args.models:models={n:models[n] for n in args.models}
    evaluate_full(models,args.output_dir,seed=args.seed)
