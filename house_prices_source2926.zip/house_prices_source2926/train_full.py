"""Version 2: train and validate with ALL 1460 House Prices records.

python train_full.py --data-dir data --output-dir results_full
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
from importlib.metadata import version
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.base import clone
from sklearn.model_selection import KFold
from threadpoolctl import threadpool_limits
from full_cat import FullCatRegressor
from full_linear import make_full_linear_models
from full_cv import log_rmse

# Rounded, nonnegative weights frozen before evaluating seed 2926.
WEIGHTS = {'full_lasso_neighborhood98': .35, 'full_svr_clip': .30, 'cat_full_d5': .35}
FAMILIES = {'full_lasso_neighborhood98':'linear', 'full_svr_clip':'linear', 'cat_full_d5':'cat'}
SOURCE_FILES = ['features.py','linear_models.py','full_linear_features.py','full_linear.py','full_cat.py','full_cv.py','train_full.py']


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cache_signature(data_dir):
    here=Path(__file__).resolve().parent
    return {'data':{n:sha256(data_dir/n) for n in ['train.csv','test.csv']},
            'source':{n:sha256(here/n) for n in SOURCE_FILES},'weights':WEIGHTS,
            'model_random_seed':42,'versions':{n:version(n)for n in ['numpy','pandas','scipy','scikit-learn','catboost']}}


def templates():
    linear=make_full_linear_models()
    return {n: FullCatRegressor(name=n,seed=42,threads=1) if n.startswith('cat_') else linear[n]
            for n in WEIGHTS}


def read_all(data_dir):
    train=pd.read_csv(data_dir/'train.csv');test=pd.read_csv(data_dir/'test.csv')
    sample=pd.read_csv(data_dir/'sample_submission.csv')
    if len(train)!=1460 or len(test)!=1459:
        raise ValueError('This solution expects the original 1460/1459 competition records.')
    if not train.Id.is_unique or not test.Id.is_unique or not sample.Id.equals(test.Id):
        raise ValueError('Invalid ID order or duplicates.')
    if set(train.columns)!=set(test.columns)|{'SalePrice'}:
        raise ValueError('Train/test schema mismatch.')
    if not (train.SalePrice>0).all():raise ValueError('Invalid target.')
    # No record filter, target trimming, or sample_weight argument anywhere.
    return train.drop(columns='SalePrice'),np.log1p(train.SalePrice.to_numpy()),test


def run_cv(x,y,test,models,seed,output,cache=None,manifest=None):
    preds={};cached=[]
    splits=list(KFold(5,shuffle=True,random_state=seed).split(x))
    fold_membership=np.empty(len(x),dtype=int)
    for f,(_,iv) in enumerate(splits,1):fold_membership[iv]=f
    for n in WEIGHTS:
        key=f'{FAMILIES[n]}/{n}_seed{seed}.npz'
        artifact=cache/key if cache is not None else None
        if artifact is not None and artifact.exists():
            expected=manifest.get('artifacts',{}).get(key)
            if expected is None or sha256(artifact)!=expected:
                raise ValueError(f'Unverified cached OOF: {key}')
            with np.load(artifact) as z:
                if not np.array_equal(z['train_ids'],x.Id) or not np.array_equal(z['test_ids'],test.Id):
                    raise ValueError('OOF IDs do not match current input data.')
                if 'folds' in z and not np.array_equal(z['folds'],fold_membership):
                    raise ValueError('Cached OOF fold membership does not match the requested split.')
                p=z['oof'].copy()
            if p.shape!=(len(x),) or not np.isfinite(p).all():raise ValueError('Invalid cached OOF.')
            preds[n]=p;cached.append(n)
            print(f'Verified current-run OOF cache: {n}, seed={seed}',flush=True)
        else:
            p=np.empty(len(x))
            for f,(it,iv) in enumerate(splits,1):
                m=clone(models[n]).fit(x.iloc[it],y[it])
                p[iv]=m.predict(x.iloc[iv])
                print(f'{n} seed={seed} fold={f}: {log_rmse(y[iv],p[iv]):.6f}',flush=True)
            preds[n]=p
    blend=sum(WEIGHTS[n]*p for n,p in preds.items())
    scores={n:log_rmse(y,p) for n,p in preds.items()};scores['blend']=log_rmse(y,blend)
    folds=[log_rmse(y[iv],blend[iv]) for _,iv in splits]
    oof=pd.DataFrame({'Id':x.Id,'SalePrice':np.expm1(y),'fold':fold_membership,
        **{n+'_log1p':p for n,p in preds.items()},'blend_log1p':blend})
    oof.to_csv(output/f'oof_seed{seed}.csv',index=False)
    print(f'ALL1460 seed={seed} blended logRMSE={scores["blend"]:.6f}',flush=True)
    special={str(h):{'actual':float(np.expm1(y[x.Id.to_numpy()==h][0])),
                      'oof_prediction':float(np.expm1(blend[x.Id.to_numpy()==h][0])),
                      'fold':int(fold_membership[x.Id.to_numpy()==h][0])}for h in [524,1299]}
    return {'seed':seed,'n_splits':5,'scored_records':len(x),'excluded_ids':[],
            'exact_log_rmse':scores,'blend_fold_scores':folds,'special_sales':special,
            'cached_models':cached}


def run(data_dir,output,seeds=(42,2026,2926),cache=None):
    output.mkdir(parents=True,exist_ok=True)
    x,y,test=read_all(data_dir);models=templates();manifest=None
    if cache is not None:
        manifest=json.loads((cache/'cache_manifest.json').read_text())
        if manifest['signature']!=cache_signature(data_dir):
            raise ValueError('Cache signature differs from source/data/model settings; run without --reuse-oof.')
    report={'version':2,'metric':'RMSE(log(actual price),log(predicted price))',
        'n_train_read':len(x),'n_train_used':len(x),'n_test':len(test),'excluded_ids':[],
        'target_modified':False,'target_transform':'log1p for fitting, expm1 for predictions',
        'sample_weight_used':False,'weights':WEIGHTS,'model_random_seed':42,
        'final_strategy':'Full-data refit of each model on every one of the 1460 original records.',
        'validation_note':'Seeds 42 and 2026 informed development. Seed 2926 evaluates the frozen blend. All are resplits of the same dataset, not independent external tests.',
        'feature_note':'Linear models learn numeric feature caps from each training fold; every record and its original sale price remain in training and validation.',
        'known_previous_kaggle_score':.12375,'new_kaggle_score':None,
        'versions':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,
                    'scipy':scipy.__version__,'scikit-learn':sklearn.__version__,'catboost':version('catboost')},
        'data_sha256':cache_signature(data_dir)['data'],'validation':[]}
    with threadpool_limits(limits=1):
        for seed in seeds:
            report['validation'].append(run_cv(x,y,test,models,seed,output,cache,manifest))
        full_log=np.zeros(len(test));components=pd.DataFrame({'Id':test.Id})
        for n,w in WEIGHTS.items():
            m=clone(models[n]).fit(x,y)
            p=m.predict(test);full_log+=w*p
            components[n+'_SalePrice']=np.expm1(p)
            print(f'Final refit retained all {len(x)} records: {n}',flush=True)
    sub=pd.DataFrame({'Id':test.Id.astype(int),'SalePrice':np.expm1(full_log)})
    if not np.isfinite(sub.SalePrice).all() or not (sub.SalePrice>0).all():
        raise ValueError('Non-finite/non-positive prediction.')
    dest=output/'submission2926.csv';sub.to_csv(dest,index=False,float_format='%.6f')
    checked=pd.read_csv(dest)
    if checked.shape!=(1459,2) or list(checked)!=['Id','SalePrice'] or not checked.Id.equals(test.Id):
        raise ValueError('Invalid serialized submission.')
    report['submission_sha256']=sha256(dest)
    report['price_range']={'min':float(checked.SalePrice.min()),'max':float(checked.SalePrice.max())}
    (output/'validation_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    components.to_csv(output/'prediction_components.csv',index=False)
    print(f'Wrote and validated {dest}',flush=True)
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',type=Path,default=Path('data'))
    p.add_argument('--output-dir',type=Path,default=Path('results_full'))
    p.add_argument('--seeds',type=int,nargs='+',default=[42,2026,2926])
    p.add_argument('--skip-cv',action='store_true')
    p.add_argument('--reuse-oof',type=Path,help='Optional verified current-run experiment directory; default recomputes CV.')
    a=p.parse_args();run(a.data_dir,a.output_dir,() if a.skip_cv else a.seeds,a.reuse_oof)
