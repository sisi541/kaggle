"""Target-free, deterministic feature engineering for Ames house prices."""

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


QUALITY = {"None": 0, "Po": 1, "Fa": 2, "TA": 3, "Gd": 4, "Ex": 5}


def build_features(frame):
    """Create features without looking at target values or other data rows.

    Missing amenity categories mean the amenity is absent. Remaining missing
    numeric values deliberately stay missing for each training fold to impute.
    """
    x = frame.drop(columns=["Id", "SalePrice"], errors="ignore").copy()
    absence = [
        "Alley", "BsmtQual", "BsmtCond", "BsmtExposure", "BsmtFinType1",
        "BsmtFinType2", "FireplaceQu", "GarageType", "GarageFinish",
        "GarageQual", "GarageCond", "PoolQC", "Fence", "MiscFeature",
        "MasVnrType",
    ]
    for c in absence:
        x[c] = x[c].fillna("None")
    x["Functional"] = x["Functional"].fillna("Typ")
    # Public Ames data contains an impossible garage year (2207); repair using
    # this row's house year, without consulting sale prices or other rows.
    bad_garage_year = x["GarageYrBlt"] > x["YrSold"] + 1
    x.loc[bad_garage_year, "GarageYrBlt"] = x.loc[bad_garage_year, "YearBuilt"]
    # These missing numeric amenities represent zero, not an unknown size.
    for c in ["MasVnrArea", "BsmtFinSF1", "BsmtFinSF2", "BsmtUnfSF",
              "TotalBsmtSF", "BsmtFullBath", "BsmtHalfBath", "GarageCars", "GarageArea"]:
        x[c] = x[c].fillna(0)

    def number(c):
        return pd.to_numeric(x[c], errors="coerce").fillna(0)

    x["TotalSF"] = number("TotalBsmtSF") + number("1stFlrSF") + number("2ndFlrSF")
    x["TotalFinishedSF"] = number("GrLivArea") + number("BsmtFinSF1") + number("BsmtFinSF2")
    x["TotalBath"] = number("FullBath") + .5 * number("HalfBath") + number("BsmtFullBath") + .5 * number("BsmtHalfBath")
    x["TotalPorchSF"] = sum(number(c) for c in ["OpenPorchSF", "EnclosedPorch", "3SsnPorch", "ScreenPorch", "WoodDeckSF"])
    x["HouseAge"] = (number("YrSold") - number("YearBuilt")).clip(lower=0)
    x["RemodAge"] = (number("YrSold") - number("YearRemodAdd")).clip(lower=0)
    x["GarageAge"] = (number("YrSold") - x["GarageYrBlt"].fillna(x["YearBuilt"])).clip(lower=0)
    x["IsRemodeled"] = (x["YearBuilt"] != x["YearRemodAdd"]).astype(int)
    x["IsNew"] = (x["YearBuilt"] == x["YrSold"]).astype(int)
    x["OverallQualSquared"] = x["OverallQual"] ** 2
    x["OverallQualCubed"] = x["OverallQual"] ** 3
    for c in ["TotalSF", "GrLivArea", "GarageArea", "TotalBsmtSF", "TotalBath"]:
        x[c + "_Quality"] = number(c) * number("OverallQual")
    for c in ["PoolArea", "2ndFlrSF", "GarageArea", "TotalBsmtSF", "Fireplaces", "MasVnrArea", "WoodDeckSF"]:
        x["Has_" + c] = (number(c) > 0).astype(int)
    for c in ["ExterQual", "ExterCond", "BsmtQual", "BsmtCond", "HeatingQC", "KitchenQual", "FireplaceQu", "GarageQual", "GarageCond", "PoolQC"]:
        x[c + "_Ordinal"] = x[c].map(QUALITY).astype(float)
    ordinals = {
        "BsmtExposure": {"None": 0, "No": 1, "Mn": 2, "Av": 3, "Gd": 4},
        "BsmtFinType1": {"None": 0, "Unf": 1, "LwQ": 2, "Rec": 3, "BLQ": 4, "ALQ": 5, "GLQ": 6},
        "BsmtFinType2": {"None": 0, "Unf": 1, "LwQ": 2, "Rec": 3, "BLQ": 4, "ALQ": 5, "GLQ": 6},
        "GarageFinish": {"None": 0, "Unf": 1, "RFn": 2, "Fin": 3},
        "Functional": {"Sal": 0, "Sev": 1, "Maj2": 2, "Maj1": 3, "Mod": 4, "Min2": 5, "Min1": 6, "Typ": 7},
        "LotShape": {"IR3": 0, "IR2": 1, "IR1": 2, "Reg": 3},
        "PavedDrive": {"N": 0, "P": 1, "Y": 2},
    }
    for c, mapping in ordinals.items():
        x[c + "_Ordinal"] = x[c].map(mapping).astype(float)
    # Class and month are nominal codes rather than continuous quantities.
    for c in ["MSSubClass", "MoSold"]:
        x[c] = x[c].astype(str)
    for c in x.select_dtypes(include=["object", "string"]).columns:
        x[c] = x[c].fillna("Missing").astype(str)
    return x


class AmesFeatures(TransformerMixin, BaseEstimator):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return build_features(X)
