"""Complementary tree models; preprocessing is fitted inside each CV fold."""
import numpy as np
from lightgbm import LGBMRegressor
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from features import AmesFeatures


def make_tree_models(threads=1):
    estimators = {
        'gbr_huber': GradientBoostingRegressor(
            n_estimators=2500, learning_rate=.025, max_depth=3,
            max_features=.7, min_samples_leaf=10, min_samples_split=10,
            loss='huber', random_state=42),
        'lgb_small': LGBMRegressor(
            n_estimators=2200, learning_rate=.012, num_leaves=5,
            max_depth=-1, min_child_samples=15, colsample_bytree=.75,
            subsample=.8, subsample_freq=1, reg_alpha=.01, reg_lambda=.1,
            random_state=42, n_jobs=threads, verbosity=-1),
        'lgb_medium': LGBMRegressor(
            n_estimators=1800, learning_rate=.015, num_leaves=12,
            min_child_samples=15, colsample_bytree=.7,
            subsample=.8, subsample_freq=1, reg_alpha=.05, reg_lambda=1,
            random_state=42, n_jobs=threads, verbosity=-1),
    }
    result = {}
    for name, estimator in estimators.items():
        result[name] = Pipeline([
            ('features', AmesFeatures()),
            ('columns', ColumnTransformer([
                ('numeric', SimpleImputer(strategy='median'),
                 make_column_selector(dtype_include=np.number)),
                ('categorical', OneHotEncoder(handle_unknown='ignore', sparse_output=False),
                 make_column_selector(dtype_include=['object', 'string'])),
            ], sparse_threshold=0)),
            ('model', estimator),
        ])
    return result
