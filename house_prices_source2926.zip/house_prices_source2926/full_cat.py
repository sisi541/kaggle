"""All-record CatBoost experiments with row-local, target-free Ames features.

No row is filtered or downweighted. All categorical combinations below are
formed from predictors and feature preprocessing uses no sale-price statistics.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.model_selection import KFold

from features import build_features


FULL_CAT_CONFIGS = {
    'cat_full_d4': dict(iterations=2400, depth=4, learning_rate=.035,
                        l2_leaf_reg=10, random_strength=.5,
                        bagging_temperature=.5),
    'cat_full_d5': dict(iterations=2000, depth=5, learning_rate=.04,
                        l2_leaf_reg=10, random_strength=.5,
                        bagging_temperature=.5),
}


def cat_features_full(frame: pd.DataFrame) -> pd.DataFrame:
    """Generate features for every record, including exceptional sales."""
    x = build_features(frame).copy()
    zero = lambda c: pd.to_numeric(x[c], errors='coerce').fillna(0)
    x['LivingPerRoom'] = zero('GrLivArea') / zero('TotRmsAbvGrd').clip(lower=1)
    x['LotLivingRatio'] = zero('LotArea') / zero('GrLivArea').clip(lower=1)
    x['BasementLivingRatio'] = zero('TotalBsmtSF') / zero('GrLivArea').clip(lower=1)
    x['FinishedBasementRatio'] = (zero('BsmtFinSF1') + zero('BsmtFinSF2')) / zero('TotalBsmtSF').clip(lower=1)
    # Crosses let categorical regularization share information about submarkets.
    # They do not use the target, ID, or any hand-labelled exceptional regime.
    pairs = [('Neighborhood', 'SaleCondition'), ('Neighborhood', 'SaleType'),
             ('Neighborhood', 'MSSubClass'), ('Neighborhood', 'HouseStyle'),
             ('SaleType', 'SaleCondition'), ('Exterior1st', 'Exterior2nd'),
             ('Foundation', 'BsmtQual')]
    for a, b in pairs:
        x[a + '__' + b] = x[a].astype(str) + '__' + x[b].astype(str)
    for c in x.select_dtypes(include=['object', 'string']).columns:
        x[c] = x[c].fillna('__MISSING__').astype(str)
    return x


def make_full_cat(name='cat_full_d4', seed=42, threads=1):
    return CatBoostRegressor(**FULL_CAT_CONFIGS[name], loss_function='RMSE',
                             random_seed=seed, thread_count=threads,
                             verbose=False, allow_writing_files=False)


class FullCatRegressor(RegressorMixin, BaseEstimator):
    """Raw-DataFrame sklearn-compatible wrapper for refit and common CV."""
    def __init__(self, name='cat_full_d4', seed=42, threads=1):
        self.name = name
        self.seed = seed
        self.threads = threads

    def fit(self, X, y):
        x = cat_features_full(X)
        self.model_ = make_full_cat(self.name, self.seed, self.threads)
        self.model_.fit(x, y, cat_features=list(x.select_dtypes(include=['object', 'string']).columns))
        self.n_features_in_ = X.shape[1]
        return self

    def predict(self, X):
        return self.model_.predict(cat_features_full(X))


def exact_log_rmse(prices, log1p_predictions):
    return float(np.sqrt(np.mean((np.log(prices) - np.log(np.expm1(log1p_predictions))) ** 2)))


def run_cv(data_dir='data', output_dir='full_experiments/cat', models=None, seed=42, threads=1):
    data_dir, output_dir = Path(data_dir), Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    train, test = pd.read_csv(data_dir / 'train.csv'), pd.read_csv(data_dir / 'test.csv')
    assert len(train) == 1460, 'Expected every one of the 1460 training records.'
    y = np.log1p(train.SalePrice.to_numpy())
    x, xt = cat_features_full(train), cat_features_full(test)
    categories = list(x.select_dtypes(include=['object', 'string']).columns)
    splitter = KFold(5, shuffle=True, random_state=seed)
    path = output_dir / f'metrics_seed{seed}.json'
    summary = json.loads(path.read_text()) if path.exists() else {}
    for name in models or FULL_CAT_CONFIGS:
        begin = time.monotonic()
        oof, pred = np.empty(len(train)), np.zeros(len(test))
        fold_membership = np.empty(len(train), dtype=int)
        scores = []
        for fold, (it, iv) in enumerate(splitter.split(x), 1):
            model = make_full_cat(name, threads=threads)
            model.fit(x.iloc[it], y[it], cat_features=categories)
            oof[iv] = model.predict(x.iloc[iv])
            fold_membership[iv] = fold
            pred += model.predict(xt) / 5
            score = exact_log_rmse(train.SalePrice.to_numpy()[iv], oof[iv])
            scores.append(score)
            print(f'{name} seed{seed} fold{fold} logRMSE={score:.6f}', flush=True)
        score = exact_log_rmse(train.SalePrice, oof)
        exceptions = train.Id.isin([524, 1299]).to_numpy()
        summary[name] = dict(exact_log_rmse=score, folds=scores,
                              exceptional_sales_oof_prices=np.expm1(oof[exceptions]).tolist(),
                              retained_rows=len(train), seconds=time.monotonic()-begin,
                              params=FULL_CAT_CONFIGS[name], n_train=len(train),
                              seed=seed, n_splits=5, excluded_ids=[],
                              special_sales={str(int(train.Id.iloc[i])):
                                  {'actual':float(train.SalePrice.iloc[i]),
                                   'oof_prediction':float(np.expm1(oof[i]))}
                                  for i in np.flatnonzero(exceptions)})
        np.savez_compressed(output_dir / f'{name}_seed{seed}.npz',
                            oof=oof, test=pred, train_ids=train.Id.to_numpy(),
                            test_ids=test.Id.to_numpy(), folds=fold_membership)
        path.write_text(json.dumps(summary, indent=2)+'\n')
        print(f'{name} seed{seed} OOF={score:.6f}', flush=True)
    return summary


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--data-dir', default='data')
    p.add_argument('--output-dir', default='full_experiments/cat')
    p.add_argument('--models', nargs='+')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--threads', type=int, default=1)
    a = p.parse_args()
    run_cv(a.data_dir, a.output_dir, a.models, a.seed, a.threads)
