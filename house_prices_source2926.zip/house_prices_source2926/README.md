# House Prices：submission2926

交付文件为 `results/submission2926.csv`，可直接上传到 Kaggle 的
**House Prices - Advanced Regression Techniques** 竞赛。
文件包含 1459 行预测，列名为 `Id,SalePrice`，没有额外索引列。

## 本地验证结果

指标严格按比赛说明计算：
`sqrt(mean((log(真实售价) - log(预测售价)) ** 2))`。

| 模型 | 五折，seed=42 | 五折，seed=2026 |
| --- | ---: | ---: |
| Lasso | 0.109289 | 0.108641 |
| SVR | 0.109188 | 0.108843 |
| **Lasso/SVR 等权融合** | **0.107427** | **0.106861** |

seed=42 用于模型选择；确定等权融合后，使用 seed=2026 进行稳定性确认，
没有在第二种划分上调参。表中是逐样本 OOF 总体 RMSE，非折 RMSE 的简单平均。

这些分数是在按固定规则剔除两个异常销售样本后的 **1458 条训练记录** 上得到的，
不等同于完整 1460 条记录的交叉验证成绩。没有测试集真实价格，未代为提交 Kaggle，
**无法保证线上分数为 0.11**；线上表现需要上传 CSV 后确认。

## 复现

已验证环境：Python 3.12.14，CPU，无需 GPU、Kaggle API 密钥或外部数据。
源码包附带用户提供的竞赛数据，解压后进入包含 `train.py` 的目录运行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python train.py --data-dir data --output-dir results
```

该命令重新执行两组五折验证，然后在全部清洗后训练记录上重训两种模型，
融合对数预测，并以 `expm1` 还原为价格。输出：

- `results/submission2926.csv`：可提交文件。
- `results/validation_report.json`：指标、每折成绩、版本、数据及提交文件 SHA-256。
- `results/oof_seed42.csv`、`results/oof_seed2026.csv`：OOF 对数预测，可独立计算指标。
- `results/prediction_components.csv`：全量重训后各基模型的价格预测。

只重新训练并生成 CSV，不重新进行交叉验证：

```bash
python train.py --data-dir data --output-dir fresh_results --skip-cv
```

本次执行了完整流程，并另行执行 `--skip-cv`，两次生成的 CSV 逐字节一致。
`--save-models` 可额外保存两个 joblib 模型。

## 方法

1. 以 `log1p(SalePrice)` 为训练目标，评估时使用比赛的精确自然对数指标。
2. 固定异常规则：删除 `GrLivArea > 4000 且 SalePrice < 300000` 的两条训练记录，
   对应 ID 524、1299；保留其他正常的大面积高价住宅。测试记录全部保留。
3. 按房屋语义处理设施缺失；把 `MSSubClass`、月份等作为类别。
   修正车库建造年份明显晚于出售年份的错误值，使用该行的房屋建造年份。
4. 构造总面积、装修后年数、房龄、总浴室、门廊、设施标志、品质等级及面积品质交互。
5. 每一训练折单独拟合中位数填补、偏态列 Box-Cox 变换、RobustScaler 和独热编码。
   未使用标签编码、测试目标或外部房价数据。`Id` 不进入预测特征。
6. Lasso：alpha=0.00045；SVR：C=20、epsilon=0.008、gamma=0.0003。
   最终融合为 `expm1(0.5*Lasso_log1p + 0.5*SVR_log1p)`。
   CSV 来自全量重训模型，而不是把验证集预测拼到测试集中。

## 文件与辅助实验

- `train.py`：最终模型完整训练、验证、生成提交文件的入口。
- `features.py`：无目标依赖的逐行特征工程。
- `linear_models.py`：折内预处理与各回归器。
- `requirements.txt`：最终方案的固定依赖版本。
- `evaluate_models.py`、`tree_models.py`、`cat_model.py`：辅助模型实验代码，
  不参与最终提交的生成。运行前安装 `requirements-experiments.txt`。

可选辅助实验命令：

```bash
python -m pip install -r requirements-experiments.txt
python evaluate_models.py --family tree --output-dir experiment_tree
python cat_model.py --models cat_d4 --output-dir experiment_cat
```

提交格式检查已完成：测试 ID 顺序完全一致，1459 个 ID 无重复，所有价格均为正且有限。
辅助实验没有改变原始 CSV，也没有针对特定测试 ID 手工指定售价。

辅助模型 seed=42 的精确对数 OOF RMSE：GBR 0.117322、LightGBM
0.118207/0.119109、CatBoost 约 0.115468。给核心融合增加少量树模型权重
在首轮划分上有约 0.0006–0.0008 的改善；最终保留已在第二种划分确认过的
等权 Lasso/SVR 方案。辅助实验汇总见 `experiment_summary.json`。
