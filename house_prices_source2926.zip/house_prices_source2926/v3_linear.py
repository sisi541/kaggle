"""Location-adaptive linear models; all original records remain in every split."""
import argparse
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator,TransformerMixin
from sklearn.compose import ColumnTransformer,make_column_selector
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Lasso,Ridge,ElasticNet
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder,RobustScaler
from full_linear_features import FullAmesFeatures
from linear_models import SkewedNumeric
from full_cv import evaluate_full


class SpatialFeatures(TransformerMixin,BaseEstimator):
    def __init__(self,neighborhood_quantile=.98,interactions=True):
        self.neighborhood_quantile=neighborhood_quantile
        self.interactions=interactions

    def fit(self,X,y=None):
        self.base_=FullAmesFeatures(interactions=True,neighborhood_quantile=self.neighborhood_quantile).fit(X)
        base=self.base_.transform(X)
        self.levels_={c:sorted(base[c].unique())for c in ['Neighborhood','SaleCondition','MSSubClass']}
        columns=['GrLivArea','TotalSF','OverallQual','HouseAge']
        self.centers_={c:float(np.median(self._values(base,c)))for c in columns}
        return self

    def _values(self,x,c):
        z=pd.to_numeric(x[c],errors='coerce').fillna(0)
        return np.log1p(z.clip(lower=0)) if c in ['GrLivArea','TotalSF','HouseAge'] else z/10

    def transform(self,X):
        x=self.base_.transform(X)
        extra={}
        if self.interactions:
            for cat,cols in [('Neighborhood',['GrLivArea','TotalSF','OverallQual','HouseAge']),
                             ('SaleCondition',['GrLivArea','OverallQual']),
                             ('MSSubClass',['GrLivArea','OverallQual'])]:
                for c in cols:
                    values=self._values(x,c)-self.centers_[c]
                    for level in self.levels_[cat]:
                        extra[f'{cat}_{level}_x_{c}']=(x[cat]==level).astype(float)*values
        # Per-area room ratios are useful nonlinear summaries, without labels.
        extra['LivingPerRoom']=x.GrLivArea/x.TotRmsAbvGrd.clip(lower=1)
        extra['LotPerLiving']=x.LotArea/x.GrLivArea.clip(lower=1)
        extra['BathsPerLiving']=1000*x.TotalBath/x.GrLivArea.clip(lower=1)
        return pd.concat([x,pd.DataFrame(extra,index=x.index)],axis=1)


def preprocessor(neighborhood_quantile=.98,interactions=True):
    return Pipeline([
        ('features',SpatialFeatures(neighborhood_quantile,interactions)),
        ('columns',ColumnTransformer([
            ('numeric',Pipeline([('impute',SimpleImputer(strategy='median')),
                ('skew',SkewedNumeric()),('scale',RobustScaler())]),make_column_selector(dtype_include=np.number)),
            ('category',OneHotEncoder(handle_unknown='ignore',sparse_output=False),
                make_column_selector(dtype_include=['object','string'])),
        ],sparse_threshold=0))])


def make_v3_linear_models():
    configs={
        'spatial_lasso98':(Lasso(alpha=.0005,max_iter=50000,tol=1e-5),.98,True),
        'spatial_ridge98':(Ridge(alpha=30),.98,True),
        'spatial_lasso99':(Lasso(alpha=.0005,max_iter=50000,tol=1e-5),.99,True),
        'spatial_ridge99':(Ridge(alpha=60),.99,True),
        'areaonly_lasso98':(Lasso(alpha=.0005,max_iter=50000,tol=1e-5),.98,False),
        'areaonly_enet98':(ElasticNet(alpha=.0007,l1_ratio=.7,max_iter=50000,tol=1e-5),.98,False),
    }
    return {n:Pipeline([('preprocess',preprocessor(q,ints)),('model',m)])for n,(m,q,ints)in configs.items()}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=42);p.add_argument('--models',nargs='+')
    a=p.parse_args();models=make_v3_linear_models()
    if a.models:models={n:models[n]for n in a.models}
    evaluate_full(models,'v3_experiments/linear',seed=a.seed)
