"""Third-round CatBoost candidates, keeping every original training record."""
from __future__ import annotations

import argparse
import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from sklearn.base import BaseEstimator, RegressorMixin

from full_cat import cat_features_full
from full_cv import evaluate_full


CONFIGS = {
    'v3_cat_raw6': dict(iterations=2800, learning_rate=.03, depth=6,
                        l2_leaf_reg=3, random_strength=.2, bagging_temperature=.3,
                        one_hot_max_size=4),
    'v3_cat_ordered5': dict(iterations=1800, learning_rate=.04, depth=5,
                            l2_leaf_reg=5, random_strength=.3,
                            bagging_temperature=.4, boosting_type='Ordered'),
    'v3_cat_huber5': dict(iterations=2400, learning_rate=.035, depth=5,
                          l2_leaf_reg=5, random_strength=.3,
                          bagging_temperature=.4, loss_function='Huber:delta=0.12'),
}


def raw_cat_features(frame):
    """Compact row-local native categorical design, without quality polynomials."""
    x=frame.drop(columns=['Id','SalePrice'],errors='ignore').copy()
    for c in ['MSSubClass','MoSold']:
        x[c]=x[c].fillna(-1).astype(int).astype(str)
    invalid=x.GarageYrBlt>x.YrSold+1
    x.loc[invalid,'GarageYrBlt']=x.loc[invalid,'YearBuilt']
    num=lambda c:pd.to_numeric(x[c],errors='coerce').fillna(0)
    extra={
        'TotalSF':num('TotalBsmtSF')+num('1stFlrSF')+num('2ndFlrSF'),
        'FinishedSF':num('GrLivArea')+num('BsmtFinSF1')+num('BsmtFinSF2'),
        'TotalBath':num('FullBath')+.5*num('HalfBath')+num('BsmtFullBath')+.5*num('BsmtHalfBath'),
        'HouseAge':(num('YrSold')-num('YearBuilt')).clip(lower=0),
        'RemodelAge':(num('YrSold')-num('YearRemodAdd')).clip(lower=0),
        'LivingPerRoom':num('GrLivArea')/num('TotRmsAbvGrd').clip(lower=1),
        'BasementLivingRatio':num('TotalBsmtSF')/num('GrLivArea').clip(lower=1),
        'FinishedBasementRatio':(num('BsmtFinSF1')+num('BsmtFinSF2'))/num('TotalBsmtSF').clip(lower=1),
        'TotalPorch':sum(num(c) for c in ['WoodDeckSF','OpenPorchSF','EnclosedPorch','3SsnPorch','ScreenPorch']),
    }
    for a,b in [('Neighborhood','SaleCondition'),('Neighborhood','SaleType'),('OverallQual','SaleCondition')]:
        extra[a+'__'+b]=x[a].astype(str)+'__'+x[b].astype(str)
    x=pd.concat([x,pd.DataFrame(extra,index=x.index)],axis=1)
    for c in x.select_dtypes(include=['object','string']).columns:
        x[c]=x[c].fillna('__MISSING__').astype(str)
    return x


class V3CatRegressor(RegressorMixin,BaseEstimator):
    def __init__(self,name='v3_cat_raw6',seed=42,threads=1):
        self.name=name;self.seed=seed;self.threads=threads

    def features(self,X):
        return cat_features_full(X) if self.name=='v3_cat_huber5' else raw_cat_features(X)

    def fit(self,X,y):
        x=self.features(X)
        cfg=dict(CONFIGS[self.name])
        cfg.setdefault('loss_function','RMSE')
        self.model_=CatBoostRegressor(**cfg,random_seed=self.seed,thread_count=self.threads,
                                     verbose=False,allow_writing_files=False)
        self.model_.fit(x,y,cat_features=list(x.select_dtypes(include=['object','string']).columns))
        self.n_features_in_=X.shape[1]
        return self

    def predict(self,X):
        return self.model_.predict(self.features(X))


def make_v3_cat_models():
    return {name:V3CatRegressor(name=name) for name in CONFIGS}


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--models',nargs='+')
    p.add_argument('--output-dir',default='v3_experiments/cat')
    args=p.parse_args();models=make_v3_cat_models()
    if args.models:models={n:models[n] for n in args.models}
    evaluate_full(models,args.output_dir,seed=args.seed)
