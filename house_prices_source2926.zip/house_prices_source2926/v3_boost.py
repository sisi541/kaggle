"""All-record V3 boosting candidates, including fold-local residual boosting."""
from __future__ import annotations
import argparse
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin, TransformerMixin, clone
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from lightgbm import LGBMRegressor
from features import build_features
from full_linear import make_full_linear_models
from full_cv import evaluate_full


class BoostFeatures(TransformerMixin,BaseEstimator):
    def fit(self,X,y=None):return self
    def transform(self,X):
        x=build_features(X).copy()
        extra={}
        for a,b in [('Neighborhood','SaleCondition'),('Neighborhood','SaleType'),
                    ('Neighborhood','MSSubClass'),('Foundation','BsmtQual')]:
            extra[a+'__'+b]=x[a].astype(str)+'__'+x[b].astype(str)
        for a,b in [('GrLivArea','TotRmsAbvGrd'),('LotArea','GrLivArea'),
                    ('TotalBsmtSF','GrLivArea')]:
            extra[a+'_per_'+b]=x[a]/x[b].clip(lower=1)
        return pd.concat([x,pd.DataFrame(extra,index=x.index)],axis=1)


def dense_preprocessor():
    return Pipeline([
        ('features',BoostFeatures()),
        ('columns',ColumnTransformer([
            ('numeric',SimpleImputer(strategy='median'),make_column_selector(dtype_include=np.number)),
            ('category',OneHotEncoder(handle_unknown='ignore',sparse_output=False),
             make_column_selector(dtype_include=['object','string'])),
        ],sparse_threshold=0))])


class NativeLGBRegressor(RegressorMixin,BaseEstimator):
    def __init__(self,num_leaves=7,n_estimators=2200,learning_rate=.015,
                 min_child_samples=10,reg_lambda=3,threads=1,cat_smooth=3,
                 cat_l2=3,min_data_per_group=5):
        self.num_leaves=num_leaves;self.n_estimators=n_estimators
        self.learning_rate=learning_rate;self.min_child_samples=min_child_samples
        self.reg_lambda=reg_lambda;self.threads=threads
        self.cat_smooth=cat_smooth;self.cat_l2=cat_l2;self.min_data_per_group=min_data_per_group
    def _features(self,X,fit=False):
        x=BoostFeatures().transform(X)
        if fit:
            self.category_levels_={c:sorted(x[c].fillna('Missing').astype(str).unique())
                                   for c in x.select_dtypes(include=['object','string'])}
        for c,levels in self.category_levels_.items():
            x[c]=pd.Categorical(x[c].fillna('Missing').astype(str),categories=levels)
        return x
    def fit(self,X,y):
        x=self._features(X,fit=True)
        self.model_=LGBMRegressor(n_estimators=self.n_estimators,num_leaves=self.num_leaves,
            learning_rate=self.learning_rate,min_child_samples=self.min_child_samples,
            colsample_bytree=.8,subsample=.85,subsample_freq=1,reg_alpha=.01,
            reg_lambda=self.reg_lambda,cat_smooth=self.cat_smooth,cat_l2=self.cat_l2,
            min_data_per_group=self.min_data_per_group,
            random_state=42,n_jobs=self.threads,verbosity=-1)
        self.model_.fit(x,y,categorical_feature=list(self.category_levels_))
        self.n_features_in_=X.shape[1]
        return self
    def predict(self,X):return self.model_.predict(self._features(X))


class ResidualBoostRegressor(RegressorMixin,BaseEstimator):
    """Base linear predictor plus regularized nonlinear residual correction.

    All stages see every training-fold row; an outer CV fold is never consulted.
    In-sample stage-one residuals are standard additive-model training targets.
    """
    def __init__(self,base_name='full_lasso_neighborhood98',n_estimators=700,
                 learning_rate=.025,max_depth=2,min_samples_leaf=15,
                 residual_scale=1.0,loss='huber'):
        self.base_name=base_name;self.n_estimators=n_estimators
        self.learning_rate=learning_rate;self.max_depth=max_depth
        self.min_samples_leaf=min_samples_leaf;self.residual_scale=residual_scale;self.loss=loss
    def fit(self,X,y):
        self.base_=clone(make_full_linear_models()[self.base_name]).fit(X,y)
        residual=np.asarray(y)-self.base_.predict(X)
        self.preprocessor_=dense_preprocessor().fit(X)
        x=self.preprocessor_.transform(X)
        self.residual_=GradientBoostingRegressor(n_estimators=self.n_estimators,
            learning_rate=self.learning_rate,max_depth=self.max_depth,
            min_samples_leaf=self.min_samples_leaf,max_features=.8,
            loss=self.loss,random_state=42).fit(x,residual)
        self.n_features_in_=X.shape[1]
        return self
    def predict(self,X):
        return self.base_.predict(X)+self.residual_scale*self.residual_.predict(self.preprocessor_.transform(X))


def make_v3_boost_models():
    return {
        'v3_gbr_huber':Pipeline([('preprocess',dense_preprocessor()),
            ('model',GradientBoostingRegressor(n_estimators=2200,learning_rate=.025,
                max_depth=3,min_samples_leaf=12,min_samples_split=10,max_features=.7,
                loss='huber',random_state=42))]),
        'v3_lgb_native7':NativeLGBRegressor(num_leaves=7,n_estimators=2200,min_child_samples=10),
        'v3_lgb_native15':NativeLGBRegressor(num_leaves=15,n_estimators=1800,
            learning_rate=.02,min_child_samples=7,reg_lambda=5),
        'v3_lgb_rare':NativeLGBRegressor(num_leaves=7,n_estimators=2000,
            learning_rate=.018,min_child_samples=3,reg_lambda=3,
            cat_smooth=.1,cat_l2=.5,min_data_per_group=1),
        'v3_residual_lasso':ResidualBoostRegressor(),
        'v3_residual_ridge':ResidualBoostRegressor(base_name='full_ridge_clip',
            n_estimators=700,residual_scale=.7),
    }


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=42)
    p.add_argument('--models',nargs='+');p.add_argument('--output-dir',default='v3_experiments/boost')
    a=p.parse_args();models=make_v3_boost_models()
    if a.models:models={n:models[n]for n in a.models}
    evaluate_full(models,a.output_dir,seed=a.seed)
