"""Full-data forest baselines: every one of the 1460 houses is retained.

All transformations are target-free or learned only from each training fold.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin, clone
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.model_selection import KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from threadpoolctl import threadpool_limits

from features import build_features


class ForestFeatures(TransformerMixin, BaseEstimator):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        x = build_features(X).copy()
        # These interactions expose special sale regimes without consulting y.
        for left, right in [('Neighborhood', 'SaleCondition'),
                            ('Neighborhood', 'SaleType'),
                            ('HouseStyle', 'SaleCondition')]:
            x[left + '__' + right] = x[left].astype(str) + '|' + x[right].astype(str)
        return x


def make_full_forest_models(threads=1, seed=42):
    estimators = {
        'rf_leaf1': RandomForestRegressor(
            n_estimators=600, max_features=.8, min_samples_leaf=1,
            n_jobs=threads, random_state=seed),
        'rf_leaf2': RandomForestRegressor(
            n_estimators=500, max_features=.8, min_samples_leaf=2,
            n_jobs=threads, random_state=seed),
        'extra_trees': ExtraTreesRegressor(
            n_estimators=700, max_features=.8, min_samples_leaf=1,
            n_jobs=threads, random_state=seed),
    }
    models = {}
    for name, estimator in estimators.items():
        models[name] = Pipeline([
            ('features', ForestFeatures()),
            ('columns', ColumnTransformer([
                ('numeric', SimpleImputer(strategy='median'),
                 make_column_selector(dtype_include=np.number)),
                ('categorical', OneHotEncoder(handle_unknown='ignore', sparse_output=False),
                 make_column_selector(dtype_include=['object', 'string'])),
            ], sparse_threshold=0)),
            ('model', estimator),
        ])
    return models


def run_cv(data_dir='data', output_dir='full_experiments/forest', seed=42,
           model_names=None, threads=1):
    train = pd.read_csv(Path(data_dir) / 'train.csv')
    test = pd.read_csv(Path(data_dir) / 'test.csv')
    if len(train) != 1460:
        raise ValueError('This experiment must retain all 1460 training rows.')
    x, y = train.drop(columns='SalePrice'), np.log1p(train.SalePrice.to_numpy())
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    models = make_full_forest_models(threads=threads)
    metrics_path = output / 'metrics.json'
    metrics = json.loads(metrics_path.read_text()) if metrics_path.exists() else {}
    with threadpool_limits(limits=1):
        for name in model_names or models:
            oof, pred = np.empty(len(train)), np.zeros(len(test))
            scores = []
            for fold, (it, iv) in enumerate(KFold(5, shuffle=True, random_state=seed).split(x), 1):
                model = clone(models[name]).fit(x.iloc[it], y[it])
                oof[iv] = model.predict(x.iloc[iv])
                pred += model.predict(test) / 5
                score = float(np.sqrt(np.mean((np.log(train.SalePrice.to_numpy()[iv]) -
                                                np.log(np.expm1(oof[iv]))) ** 2)))
                scores.append(score)
                print(f'{name} seed={seed} fold={fold} exact_log_rmse={score:.6f}', flush=True)
            rmse = float(np.sqrt(np.mean((np.log(train.SalePrice) - np.log(np.expm1(oof))) ** 2)))
            exceptional = train.Id.isin([524, 1299])
            metric_key = f'{name}_seed{seed}'
            metrics[metric_key] = {
                'exact_log_rmse': rmse, 'folds': scores,
                'training_rows': len(train), 'excluded_rows': 0,
                'exceptional_sale_oof_predictions': dict(zip(
                    train.loc[exceptional, 'Id'].astype(str), np.expm1(oof[exceptional]).tolist())),
            }
            np.savez_compressed(output / f'{metric_key}.npz', oof=oof, test=pred,
                                train_ids=train.Id.to_numpy(), test_ids=test.Id.to_numpy())
            metrics_path.write_text(json.dumps(metrics, indent=2) + '\n')
            print(f'{name} seed={seed} OOF exact_log_rmse={rmse:.6f}', flush=True)
    return metrics


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', default='data')
    parser.add_argument('--output-dir', default='full_experiments/forest')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--models', nargs='+')
    parser.add_argument('--threads', type=int, default=1)
    args = parser.parse_args()
    run_cv(args.data_dir, args.output_dir, args.seed, args.models, args.threads)
