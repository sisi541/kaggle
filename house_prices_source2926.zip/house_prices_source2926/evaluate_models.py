"""Shared, auditable five-fold evaluation and fold-averaged test predictions."""
import argparse
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import KFold
from threadpoolctl import threadpool_limits


def load_data(data_dir='data'):
    root = Path(data_dir)
    train = pd.read_csv(root / 'train.csv')
    test = pd.read_csv(root / 'test.csv')
    # Two well-known exceptional sales, selected by a fixed domain rule.
    keep = ~((train.GrLivArea > 4000) & (train.SalePrice < 300000))
    train = train.loc[keep].reset_index(drop=True)
    return train, test, np.log1p(train.SalePrice.to_numpy())


def evaluate(models, data_dir='data', output_dir='experiment_tree'):
    train, test, y = load_data(data_dir)
    x = train.drop(columns=['SalePrice'])
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    metrics_path = output / 'metrics.json'
    metrics = json.loads(metrics_path.read_text()) if metrics_path.exists() else {}
    folds = KFold(n_splits=5, shuffle=True, random_state=42)
    with threadpool_limits(limits=1):
        for name, template in models.items():
            oof, pred = np.empty(len(train)), np.zeros(len(test))
            scores = []
            for fold, (it, iv) in enumerate(folds.split(x), 1):
                model = clone(template)
                model.fit(x.iloc[it], y[it])
                oof[iv] = model.predict(x.iloc[iv])
                pred += model.predict(test) / folds.n_splits
                score = float(np.sqrt(np.mean((y[iv]-oof[iv])**2)))
                scores.append(score)
                print(f'{name} fold {fold}: {score:.6f}', flush=True)
            rmse = float(np.sqrt(np.mean((y-oof)**2)))
            # Also record exact competition log metric (log1p differs negligibly).
            exact_rmse = float(np.sqrt(np.mean((np.log(train.SalePrice) - np.log(np.expm1(oof)))**2)))
            metrics[name] = dict(rmse=rmse, exact_log_rmse=exact_rmse, folds=scores)
            np.savez_compressed(output / f'{name}.npz', oof=oof, test=pred,
                                train_ids=train.Id.to_numpy(), test_ids=test.Id.to_numpy())
            metrics_path.write_text(json.dumps(metrics, indent=2)+'\n')
            print(f'{name} OOF: {rmse:.6f}', flush=True)
    return metrics


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--data-dir', default='data')
    p.add_argument('--output-dir', default='experiment_tree')
    p.add_argument('--family', choices=['tree', 'linear'], default='tree')
    p.add_argument('--models', nargs='+')
    args = p.parse_args()
    if args.family == 'tree':
        from tree_models import make_tree_models
        models = make_tree_models()
    else:
        from linear_models import make_linear_models
        models = make_linear_models()
    if args.models:
        models = {name: models[name] for name in args.models}
    evaluate(models, args.data_dir, args.output_dir)
